﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace DAL
{
    public class ServerConnection
    {
      public static SqlCommand Connection()
        {
            SqlCommand sqlCommand = null;
            try
            {
                SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["kusuma"].ConnectionString);
                sqlCommand = new SqlCommand();

                //Assigning common properties to command
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Connection =connection;
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            return sqlCommand;
        }
    }
}
