﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exception;
using Entity;
using System.Data.SqlClient;

namespace DAL
{
  public  class Emp_DAL
    {
        public static int Insertempent(Emp_Entity emp)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = ServerConnection.Connection();
                //Assigning command text
                cmd.CommandText = "usp_ADD_172433";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@EmployeeID",emp.EmployeeID);
                cmd.Parameters.AddWithValue("@EmployeeName",emp.EmployeeName);
                cmd.Parameters.AddWithValue("@EmployeeAddress",emp.EmployeeAddress);
                cmd.Parameters.AddWithValue("@EmployeeDOB",emp.DOB);
              

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        public static List<Emp_Entity> Retrieveemp()
        {
            List<Emp_Entity> empList = null;

            try
            {
                SqlCommand cmd = ServerConnection.Connection();
                cmd.CommandText = "usp_Display_172433";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    empList = new List<Emp_Entity>();
                    while (dr.Read())
                    {
                        Emp_Entity emp = new Emp_Entity();

                        emp.EmployeeID = (int)dr["EmployeeID"];
                        emp.EmployeeName = dr["EmployeeName"].ToString();
                        emp.EmployeeAddress = dr["EmployeeAddress"].ToString();
                        emp.DOB = Convert.ToDateTime(dr["EmployeeDOB"]);
                       

                        empList.Add(emp);
                    }
                }
                else
                    throw new Emp_Exception("Record not available");
                cmd.Connection.Close();
            }
            catch (Emp_Exception ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empList;
        }
    }
}
