﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entity;
using BAL;
using Exception;

namespace PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public void Clear()
        {
            txtid.Text = "";
            txtname.Text = "";
            txtaddress.Text = "";
            txtdate.Text = "";
           

        }
        public new void Show()
        {
            try
            {
                List<Emp_Entity> empList = Emp_BAL.RetrieveEmployee();

                if (empList == null || empList.Count <= 0)
                    throw new Emp_Exception("Records not available");
                else
                {
                    dgemp.DataContext = empList;
                }
            }
            catch (Emp_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Show();
            Clear();
        }

        private void Btnadd_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Emp_Entity emp = new Emp_Entity();

                emp.EmployeeID = Convert.ToInt32(txtid.Text);
               emp.EmployeeName = txtname.Text;
                emp.EmployeeAddress =txtaddress.Text;
                emp.DOB = Convert.ToDateTime(txtdate.Text);
                int recordsAffected = Emp_BAL.Insertemp(emp);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record inserted successfully");
                    Show();
                    Clear();
                }
                else
                    throw new Emp_Exception("Record not inserted");
            }
            catch (Emp_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
