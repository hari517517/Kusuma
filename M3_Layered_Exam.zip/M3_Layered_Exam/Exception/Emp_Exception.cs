﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception
{
    public class Emp_Exception:ApplicationException
    {
        public Emp_Exception():base()
        {

        }
        public Emp_Exception(string message):base(message)
        {

        }
    }
}
