﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using Exception;
using DAL;
using System.Text.RegularExpressions;

namespace BAL
{
    public class Emp_BAL
    {

        public static bool Valildateempent(Emp_Entity emp)
        {
            bool empValidated = true;
            StringBuilder stringBuilder = new StringBuilder();

            try
            {
                if (emp.EmployeeID < 0 || emp.EmployeeID > 99999)
                {
                    empValidated = false;
                    stringBuilder.Append("empent code should be greater than 0 and less than the 99999\n");
                }

                if (emp.EmployeeName == String.Empty)
                {
                    empValidated = false;
                    stringBuilder.Append("empent name should be provided\n");
                }
                else if (!Regex.IsMatch(emp.EmployeeName, "[A-Z][a-z]+"))
                {
                    empValidated = false;
                    stringBuilder.Append("empent Name should Start with Capitals only\n");
                }

                if (emp.EmployeeAddress == string.Empty)
                {
                    empValidated = false;
                    stringBuilder.Append("empent Date of Birth should be provided\n");
                }
                if (emp.DOB > DateTime.Now)
                {
                    empValidated = false;
                    stringBuilder.Append("dob should provide");
                }

                if (empValidated == false)
                    throw new Emp_Exception(stringBuilder.ToString());
            }
            catch (Emp_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empValidated;
        }
            public static List<Emp_Entity> RetrieveEmployee()
            {
                List<Emp_Entity> empList = null;

                try
                {
                empList = Emp_DAL.Retrieveemp();
                }
                catch (Emp_Exception ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return empList;
            }

        public static int Insertemp(Emp_Entity emp)
        {
            int recordsAffected = 0;

            try
            {
                if (Valildateempent(emp))
                {
                    recordsAffected =Emp_DAL.Insertempent(emp);
                }
                else
                    throw new Emp_Exception("Please provide valid Student Information");
            }
            catch (Emp_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

    }

}

