﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Emp_Entity
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string  EmployeeAddress { get; set; }
        public DateTime DOB { get; set; }
    }
}
