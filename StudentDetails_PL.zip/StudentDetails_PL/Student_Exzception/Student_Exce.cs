﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Exzception
{
    public class Student_Exce :ApplicationException
    {
        public Student_Exce(string message):base(message)
        {

        }

    }
}
