﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Student_Entities;
using Student_Exzception;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Student_DAL
{
    public class DataConnection
    {
        
        public static SqlCommand GenerateCommand()
        {
            SqlCommand cmd = null;

            try 
            {
                //Creating connection object
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
                //Creating Command object
                cmd = new SqlCommand();

                //Assigning common properties to command
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cmd;
        }
    }
}
