﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Student_DAL;
using Student_Entities;
using Student_Exzception;

namespace Student_BAL
{
    public class StudentBAl
    {
        public static bool ValildateStudent(StudentEntity stud)
        {
            bool studValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (stud.Scode<0||stud.Scode>99999)
                {
                    studValidated = false;
                    message.Append("Student code should be greater than 0 and less than the 99999\n");
                }

                if (stud.SName == String.Empty)
                {
                    studValidated = false;
                    message.Append("Student name should be provided\n");
                }
                else if (!Regex.IsMatch(stud.SName, "[A-Z][a-z]+"))
                {
                    studValidated = false;
                    message.Append("Student Name should Start with Capitals only\n");
                }

                if (stud.Dob == null)
                {
                    studValidated = false;
                    message.Append("Student Date of Birth should be provided\n");
                }

                if (studValidated == false)
                    throw new Student_Exce(message.ToString());
            }
            catch (Student_Exce ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studValidated;
        }

        public static int InsertStudent(StudentEntity stud)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateStudent(stud))
                {
                    recordsAffected = StudentOperation.InsertStudent(stud);
                }
                else
                    throw new Student_Exce("Please provide valid Student Information");
            }
            catch (Student_Exce ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateStudent(StudentEntity stud)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateStudent(stud))
                {
                    recordsAffected = StudentOperation.UpdateStudent(stud);
                }
                else
                    throw new Student_Exce("Please provide valid Student Information");
            }
            catch (Student_Exce ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteStudent(int studCode)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = StudentOperation.DeleteStudent(studCode);
            }
            catch (Student_Exce ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static StudentEntity SearchStudent(int studCode)
        {
            StudentEntity stud = null;

            try
            {
                stud = StudentOperation.SearchStudent(studCode);
            }
            catch (Student_Exce ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        public static List<StudentEntity> RetrieveStudent()
        {
            List<StudentEntity> studList = null;

            try
            {
                studList = StudentOperation.RetrieveStudent();
            }
            catch (Student_Exce ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }

    }
}
