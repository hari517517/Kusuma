﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Entities
{
    public class StudentEntity
    {
        public int Scode { get; set; }
        public string SName { get; set; }
        public int DCode { get; set; }
        public DateTime Dob { get; set; }
        public string Address { get; set; }
    }
}
